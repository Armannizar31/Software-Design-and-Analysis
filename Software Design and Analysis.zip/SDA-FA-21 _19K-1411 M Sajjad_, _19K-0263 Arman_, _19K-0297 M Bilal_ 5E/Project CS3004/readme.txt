Extract all files out of zip.
You must have Xampp installed on your PC.
Add attached ecommerce database to Xampp.
Copy code/project/ folder into Xampp/htdocs folder.
To edit code open code/project/ on Visual Studio or any other IDE.
