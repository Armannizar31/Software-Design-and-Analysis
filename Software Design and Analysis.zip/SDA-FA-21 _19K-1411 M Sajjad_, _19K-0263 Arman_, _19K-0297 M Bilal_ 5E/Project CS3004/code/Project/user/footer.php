<div class="footer">
        <div class="container">
            <div class="row">
            <div class="footer-col-1">
                <h3>Download Our App</h3>
                <p>Download App fpr Android and ios mobile phone</p>
                </div>    
                <div class="footer-col-2">
                <img src="../images/logo-white.png">
                <p>Our Purpose Is to Sustainably Make the pleasure and benefits of Sports To th Many</p>
                </div> 
                <div class="footer-col-3">
                <h3>Useful links</h3>
               <ul>
                <li>Coupons</li>
                <li>Blogs Post</li>
                   <li>Return Policy</li>
                   <li>Join Affiliate</li>  
                </ul>
            
            </div>
        </div>
    </div>
        </div>